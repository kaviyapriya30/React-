package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Register;

import com.example.demo.service.Babyservice;


@RestController
@CrossOrigin(origins = {"http://localhost:3000"})
public class Babycontroller {
	
	@Autowired
	Babyservice service;
	
	@PostMapping(value="/save")
	public Register print(@RequestBody Register register) throws Exception
	{
		String tempemail=register.getEmail();
		if(tempemail!= null && "".equals(tempemail))
		{
			Register obj=service.fetchuserbyemail(tempemail);
		   if(obj !=null)
		   {
			   throw new Exception("User is "+tempemail+" already exits");
		   }
		}
		Register obj=null;
		obj=service.store(register);
		return obj;
		
	}
	@GetMapping(value="/listuser",consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Register>> saveuser()
	{
		List<Register> list=service.getuser();
		return new ResponseEntity<List<Register>>(list,HttpStatus.CREATED);
		
	}
	@PostMapping("/login")
	public Register loginuser(@RequestBody Register user) throws Exception
	{
		String tempemail=user.getEmail();
		String temppass=user.getPassword();
		Register obj=null;
		if(tempemail !=null && temppass!=null) {
			obj=service.fetchuserbyemailandpass(tempemail, temppass);
			
		}
		if(obj ==null)
		{
			throw new Exception("User doesnot exits");
		}
		return obj;
		
	}

}
